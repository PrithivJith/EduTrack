import React from 'react'

const Test = () => {
  return (
    <div className='relative top-20'>
      <h1>Hello</h1>
    </div>
  )
}

export default Test
