import React, { useState, useEffect } from "react";
import NavigationBar from "./components/NavigationBar";

import axios from "axios";

const Home = () => {
  
  
 
  return (
    <div>
      <NavigationBar/>
    </div>
  );
};

export default Home;
